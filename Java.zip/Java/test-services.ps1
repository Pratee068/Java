# Test script for Java Microservices
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Testing Java Microservices" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Wait for services to be ready
Write-Host "Waiting for services to start..." -ForegroundColor Yellow
Start-Sleep -Seconds 10

# Test 1: User Service - Get all users
Write-Host "`n1. Testing User Service - GET /api/users" -ForegroundColor Green
try {
    $users = Invoke-RestMethod -Uri "http://localhost:8081/api/users" -Method Get
    Write-Host "✓ User Service is running!" -ForegroundColor Green
    Write-Host "  Current users: $($users.Count)" -ForegroundColor Gray
} catch {
    Write-Host "✗ User Service failed: $_" -ForegroundColor Red
    exit 1
}

# Test 2: Create a User
Write-Host "`n2. Creating a new user" -ForegroundColor Green
$userBody = @{
    name = "Alice Johnson"
    email = "alice@example.com"
    phone = "+1234567890"
} | ConvertTo-Json

try {
    $user = Invoke-RestMethod -Uri "http://localhost:8081/api/users" -Method Post -Body $userBody -ContentType "application/json"
    Write-Host "✓ User created successfully!" -ForegroundColor Green
    Write-Host "  User ID: $($user.id)" -ForegroundColor Gray
    Write-Host "  Name: $($user.name)" -ForegroundColor Gray
    Write-Host "  Email: $($user.email)" -ForegroundColor Gray
    $userId = $user.id
} catch {
    Write-Host "✗ Failed to create user: $_" -ForegroundColor Red
    exit 1
}

# Test 3: Get User by ID
Write-Host "`n3. Getting user by ID" -ForegroundColor Green
try {
    $user = Invoke-RestMethod -Uri "http://localhost:8081/api/users/$userId" -Method Get
    Write-Host "✓ User retrieved successfully!" -ForegroundColor Green
    Write-Host "  Name: $($user.name)" -ForegroundColor Gray
} catch {
    Write-Host "✗ Failed to get user: $_" -ForegroundColor Red
}

# Test 4: Order Service - Get all orders
Write-Host "`n4. Testing Order Service - GET /api/orders" -ForegroundColor Green
try {
    $orders = Invoke-RestMethod -Uri "http://localhost:8082/api/orders" -Method Get
    Write-Host "✓ Order Service is running!" -ForegroundColor Green
    Write-Host "  Current orders: $($orders.Count)" -ForegroundColor Gray
} catch {
    Write-Host "✗ Order Service failed: $_" -ForegroundColor Red
    exit 1
}

# Test 5: Create an Order (Tests REST Communication + Kafka)
Write-Host "`n5. Creating a new order (Tests REST + Kafka)" -ForegroundColor Green
Write-Host "  This will:" -ForegroundColor Yellow
Write-Host "  - Call User Service via REST API to verify user exists" -ForegroundColor Yellow
Write-Host "  - Publish event to Kafka" -ForegroundColor Yellow
Write-Host "  - Notification Service will consume the Kafka event" -ForegroundColor Yellow

$orderBody = @{
    userId = $userId
    productName = "MacBook Pro"
    quantity = 1
    totalAmount = 2500.00
} | ConvertTo-Json

try {
    $order = Invoke-RestMethod -Uri "http://localhost:8082/api/orders" -Method Post -Body $orderBody -ContentType "application/json"
    Write-Host "✓ Order created successfully!" -ForegroundColor Green
    Write-Host "  Order ID: $($order.id)" -ForegroundColor Gray
    Write-Host "  Product: $($order.productName)" -ForegroundColor Gray
    Write-Host "  Quantity: $($order.quantity)" -ForegroundColor Gray
    Write-Host "  Total: `$$($order.totalAmount)" -ForegroundColor Gray
    Write-Host "  Status: $($order.status)" -ForegroundColor Gray
    $orderId = $order.id
} catch {
    Write-Host "✗ Failed to create order: $_" -ForegroundColor Red
    Write-Host "  Error details: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# Test 6: Update Order Status
Write-Host "`n6. Updating order status to SHIPPED" -ForegroundColor Green
try {
    $updatedOrder = Invoke-RestMethod -Uri "http://localhost:8082/api/orders/$orderId/status?status=SHIPPED" -Method Patch
    Write-Host "✓ Order status updated successfully!" -ForegroundColor Green
    Write-Host "  New Status: $($updatedOrder.status)" -ForegroundColor Gray
} catch {
    Write-Host "✗ Failed to update order status: $_" -ForegroundColor Red
}

# Test 7: Check Notification Service Logs
Write-Host "`n7. Checking Notification Service logs for Kafka events" -ForegroundColor Green
Write-Host "  Fetching recent logs from notification-service..." -ForegroundColor Yellow
try {
    $logs = docker logs notification-service --tail=30 2>&1 | Out-String
    if ($logs -match "NOTIFICATION SERVICE - New Order Event Received" -or $logs -match "Notification sent") {
        Write-Host "✓ Notification Service received and processed Kafka events!" -ForegroundColor Green
        Write-Host "`n  Recent notification logs:" -ForegroundColor Gray
        $logs -split "`n" | Select-Object -Last 20 | ForEach-Object {
            if ($_ -match "Order ID|User ID|Product|Status|Notification sent") {
                Write-Host "  $_" -ForegroundColor Cyan
            }
        }
    } else {
        Write-Host "⚠ No notification events found in logs yet (may take a moment)" -ForegroundColor Yellow
    }
} catch {
    Write-Host "⚠ Could not retrieve notification logs: $_" -ForegroundColor Yellow
}

# Test 8: Create another order
Write-Host "`n8. Creating another order" -ForegroundColor Green
$orderBody2 = @{
    userId = $userId
    productName = "iPhone 15 Pro"
    quantity = 2
    totalAmount = 2400.00
} | ConvertTo-Json

try {
    $order2 = Invoke-RestMethod -Uri "http://localhost:8082/api/orders" -Method Post -Body $orderBody2 -ContentType "application/json"
    Write-Host "✓ Second order created successfully!" -ForegroundColor Green
    Write-Host "  Order ID: $($order2.id)" -ForegroundColor Gray
    Write-Host "  Product: $($order2.productName)" -ForegroundColor Gray
} catch {
    Write-Host "✗ Failed to create second order: $_" -ForegroundColor Red
}

# Summary
Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "Test Summary" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "✓ User Service: Working" -ForegroundColor Green
Write-Host "✓ Order Service: Working" -ForegroundColor Green
Write-Host "✓ REST Communication: User Service ← Order Service" -ForegroundColor Green
Write-Host "✓ Kafka Messaging: Order Service → Notification Service" -ForegroundColor Green
Write-Host "`nAll microservices are functioning correctly!" -ForegroundColor Green
Write-Host ""
Write-Host "You can view logs with:" -ForegroundColor Yellow
Write-Host "  docker logs user-service" -ForegroundColor Gray
Write-Host "  docker logs order-service" -ForegroundColor Gray
Write-Host "  docker logs notification-service" -ForegroundColor Gray
Write-Host ""
