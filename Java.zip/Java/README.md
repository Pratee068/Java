# Java Microservices with MySQL & Kafka

A production-ready microservices architecture built with Spring Boot, MySQL databases, and Apache Kafka messaging.

## Architecture Overview

This project demonstrates a complete microservices pattern with:

- **User Service** (Port 8081) - User management with MySQL persistence
- **Order Service** (Port 8082) - Order processing with REST + Kafka integration  
- **Notification Service** (Port 8083) - Event-driven notifications via Kafka

### Communication Patterns

```
┌─────────────────┐    REST API     ┌─────────────────┐
│   User Service  │ ◄──────────────► │  Order Service  │
│   (Port 8081)   │                  │   (Port 8082)   │
│   MySQL userdb  │                  │  MySQL orderdb  │
└─────────────────┘                  └────────┬────────┘
                                              │
                                              │ Kafka Events
                                              ▼
                                     ┌─────────────────┐
                                     │ Notification    │
                                     │    Service      │
                                     │  (Port 8083)    │
                                     └─────────────────┘
```

## Database Configuration

### MySQL Databases

Each service has its own dedicated MySQL database for data isolation:

| Service | Database | Port | User | Password |
|---------|----------|------|------|----------|
| User Service | `userdb` | 3306 | `userservice` | `userpassword` |
| Order Service | `orderdb` | 3307 | `orderservice` | `orderpassword` |

### Data Persistence

- **Docker Volumes**: `mysql-user-data` and `mysql-order-data` ensure data survives container restarts
- **Auto Schema**: Hibernate DDL auto-update creates tables automatically
- **Health Checks**: MySQL containers have built-in health monitoring

## Quick Start

### Prerequisites

- Docker Desktop installed and running
- 2GB+ available RAM for containers

### Start Services

```bash
# Build and start all services
docker-compose up -d --build

# Wait for MySQL initialization (60-90 seconds)
# Check status
docker ps
```

### Verify Setup

```bash
# Check MySQL connectivity
docker exec mysql-user mysql -uuserservice -puserpassword -e "SHOW DATABASES;"
docker exec mysql-order mysql -uorderservice -porderpassword -e "SHOW DATABASES;"

# Check service logs
docker logs user-service --tail 20
docker logs order-service --tail 20
docker logs notification-service --tail 20
```

## API Endpoints

### User Service (Port 8081)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/users` | Get all users |
| GET | `/api/users/{id}` | Get user by ID |
| POST | `/api/users` | Create new user |
| PUT | `/api/users/{id}` | Update user |
| DELETE | `/api/users/{id}` | Delete user |

### Order Service (Port 8082)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/orders` | Get all orders |
| GET | `/api/orders/{id}` | Get order by ID |
| GET | `/api/orders/user/{userId}` | Get orders by user |
| POST | `/api/orders` | Create order (triggers REST + Kafka) |
| PATCH | `/api/orders/{id}/status` | Update order status |

## Testing the APIs

### 1. Create a User

```bash
curl -X POST http://localhost:8081/api/users \
  -H "Content-Type: application/json" \
  -d '{"name":"John Doe","email":"john@test.com","phone":"123-456-7890"}'
```

**Response:**
```json
{
  "id": 1,
  "name": "John Doe",
  "email": "john@test.com", 
  "phone": "123-456-7890"
}
```

### 2. Create an Order

```bash
curl -X POST http://localhost:8082/api/orders \
  -H "Content-Type: application/json" \
  -d '{"userId":1,"productName":"MacBook Pro","quantity":1,"totalAmount":2499.99}'
```

**Response:**
```json
{
  "id": 1,
  "userId": 1,
  "productName": "MacBook Pro",
  "quantity": 1,
  "totalAmount": 2499.99,
  "status": "PENDING",
  "createdAt": "2026-01-30T..."
}
```

### 3. Verify Data Persistence

```bash
# Check user data in MySQL
docker exec mysql-user mysql -uuserservice -puserpassword \
  -e "SELECT * FROM userdb.users;"

# Check order data in MySQL  
docker exec mysql-order mysql -uorderservice -porderpassword \
  -e "SELECT * FROM orderdb.orders;"
```

### 4. Verify Kafka Messaging

```bash
# Check notification service received the order event
docker logs notification-service --tail 20
```

**Expected Output:**
```
Order ID: 1
User ID: 1
Product: MacBook Pro
Quantity: 1
Total Amount: $2499.99
Status: PENDING
✅ Notification sent: Dear User 1, your order #1 for MacBook Pro...
```

## Key Features

### 🔄 **Microservices Patterns**
- **Database per Service**: Each service owns its data
- **API Gateway Ready**: Clean REST interfaces
- **Service Discovery**: Docker DNS resolution
- **Event-Driven Architecture**: Async communication via Kafka

### 🗄️ **MySQL Integration** 
- **Persistent Storage**: Data survives restarts
- **Connection Pooling**: HikariCP for performance
- **Auto Schema Management**: Hibernate DDL
- **Health Monitoring**: Built-in health checks

### 📨 **Kafka Messaging**
- **Async Communication**: Order events trigger notifications
- **Reliable Delivery**: Kafka guarantees message delivery
- **Scalable**: Easy to add more consumers
- **Event Sourcing Ready**: All order events are logged

### 🐳 **Docker Orchestration**
- **Multi-stage Builds**: Optimized container sizes
- **Health Checks**: Automatic service monitoring
- **Volume Persistence**: Data survives container recreation
- **Network Isolation**: Services communicate securely

## Development Workflow

### Local Development
```bash
# Start only databases for local dev
docker-compose up mysql-user mysql-order kafka zookeeper -d

# Run services locally with IDE
# User Service: mvn spring-boot:run -f user-service/pom.xml
# Order Service: mvn spring-boot:run -f order-service/pom.xml  
# Notification Service: mvn spring-boot:run -f notification-service/pom.xml
```

### Hot Reload
```bash
# Rebuild and restart a single service
docker-compose build user-service
docker-compose up -d user-service
```

### Monitoring
```bash
# View all logs in real-time
docker-compose logs -f

# Monitor specific service
docker logs user-service -f

# Check container resource usage
docker stats
```

## Troubleshooting

### Services Not Starting
```bash
# Check all container status
docker ps -a

# View service logs for errors
docker logs user-service --tail 50
docker logs mysql-user --tail 50
```

### Database Connection Issues
```bash
# Test MySQL connectivity
docker exec mysql-user mysqladmin ping -h localhost -u root -proot

# Check database exists
docker exec mysql-user mysql -uroot -proot -e "SHOW DATABASES;"
```

### Kafka Issues
```bash
# Check Kafka logs
docker logs kafka --tail 50

# Verify topic creation
docker exec kafka kafka-topics.sh --list --bootstrap-server localhost:9092
```

## Cleanup

```bash
# Stop all services
docker-compose down

# Remove all data (destructive!)
docker-compose down -v

# Remove all images
docker-compose down --rmi all -v
```

## Technology Stack

- **Java 17** - Modern Java with records and text blocks
- **Spring Boot 3.2.0** - Latest framework with native compilation support
- **MySQL 8.0** - Production-grade relational database
- **Apache Kafka 7.5** - Distributed event streaming platform
- **Docker & Compose** - Containerization and orchestration
- **Maven** - Build automation and dependency management
- **Lombok** - Reduced boilerplate code

## Production Considerations

### Security
- Change default passwords in production
- Use environment variables for sensitive data
- Enable MySQL SSL connections
- Implement API authentication/authorization

### Scalability  
- Configure Kafka partitions for parallel processing
- Use read replicas for MySQL databases
- Implement circuit breakers for service calls
- Add load balancers for high availability

### Monitoring
- Add Spring Boot Actuator for health endpoints
- Integrate with monitoring systems (Prometheus, Grafana)
- Implement distributed tracing (Zipkin, Jaeger)
- Set up log aggregation (ELK stack)

