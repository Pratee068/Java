# Java Microservices Project

A production-ready microservices architecture built with **Spring Boot**, **REST APIs**, **Apache Kafka**, and **Docker**.

## 📋 Project Overview

This project demonstrates a complete microservices architecture with three interconnected services:

1. **User Service** (Port 8081) - User management with full CRUD operations
2. **Order Service** (Port 8082) - Order management with REST API communication and Kafka event publishing
3. **Notification Service** (Port 8083) - Event-driven notification processing via Kafka consumer

### Key Highlights
- ✅ **Fully Commented Code** - Every file includes detailed comments for easy understanding
- ✅ **Docker Ready** - Complete containerization with docker-compose
- ✅ **Event-Driven** - Kafka messaging for asynchronous communication
- ✅ **RESTful APIs** - Synchronous service-to-service communication
- ✅ **Production Practices** - Health checks, multi-stage builds, proper error handling

## 🏗️ Architecture

```
┌─────────────────┐      REST API      ┌─────────────────┐
│                 │ ───────────────────>│                 │
│  User Service   │                     │  Order Service  │
│   (Port 8081)   │                     │   (Port 8082)   │
│                 │                     │                 │
└─────────────────┘                     └────────┬────────┘
                                                 │
                                                 │ Kafka
                                                 │ Events
                                                 ▼
                                        ┌─────────────────┐
                                        │  Notification   │
                                        │     Service     │
                                        │   (Port 8083)   │
                                        └─────────────────┘
```

## 🚀 Technologies Used

- **Java 17**
- **Spring Boot 3.2.0**
- **Spring Data JPA**
- **H2 Database** (in-memory)
- **Apache Kafka** (message broker)
- **RestTemplate** (inter-service communication)
- **Docker & Docker Compose**
- **Maven** (build tool)

## 📁 Project Structure

```
Java/
├── user-service/
│   ├── src/
│   ├── Dockerfile
│   └── pom.xml
├── order-service/
│   ├── src/
│   ├── Dockerfile
│   └── pom.xml
├── notification-service/
│   ├── src/
│   ├── Dockerfile
│   └── pom.xml
└── docker-compose.yml
```

## 🛠️ Prerequisites

Before running this project, ensure you have:

### Required Software
- **Docker Desktop** - [Download here](https://www.docker.com/products/docker-desktop)
  - Version 20.10 or higher
  - Must be running before starting the project
- **Docker Compose** - Included with Docker Desktop
  - Version 2.0 or higher

### Optional (for local development without Docker)
- **Java 17** - [Download JDK 17](https://adoptium.net/)
- **Maven 3.8+** - [Download Maven](https://maven.apache.org/download.cgi)

### System Requirements
- **RAM**: Minimum 8GB (16GB recommended)
- **Disk Space**: 5GB free space
- **Ports**: Ensure these ports are available:
  - `8081` - User Service
  - `8082` - Order Service
  - `8083` - Notification Service
  - `9092` - Kafka
  - `2181` - Zookeeper

## 🚀 Getting Started

### Step 1: Clone or Download the Project

```bash
# If using Git
git clone <repository-url>
cd Java

# Or simply navigate to the project directory
cd c:\Project\Java
```

### Step 2: Verify Docker is Running

**Windows:**
```powershell
# Check if Docker is running
docker --version
docker ps

# If Docker is not running, start Docker Desktop from Start Menu
```

**Linux/Mac:**
```bash
# Check if Docker is running
docker --version
sudo systemctl status docker
```

### Step 3: Build and Start All Services

```bash
# Build images and start all services
docker-compose up --build -d

# Or without detached mode (to see logs)
docker-compose up --build
```

**What happens during startup:**
1. Zookeeper starts (dependency for Kafka)
2. Kafka broker starts and creates topics
3. User Service builds and starts
4. Order Service builds and starts
5. Notification Service builds and starts

**Expected startup time:** 2-5 minutes (first build takes longer)

### Step 4: Wait for Services to be Ready

```bash
# Check container status
docker ps

# Wait until you see "healthy" status for user-service and order-service
# Example output:
# user-service          Up 2 minutes (healthy)
# order-service         Up 2 minutes (healthy)
# notification-service  Up 2 minutes
```

### Step 5: Verify Services are Running

**PowerShell (Windows):**
```powershell
# Test User Service
Invoke-RestMethod -Uri "http://localhost:8081/api/users"

# Test Order Service
Invoke-RestMethod -Uri "http://localhost:8082/api/orders"

# Check all containers
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
```

**Bash (Linux/Mac):**
```bash
# Test User Service
curl http://localhost:8081/api/users

# Test Order Service
curl http://localhost:8082/api/orders

# Check all containers
docker ps
```

✅ **You're ready to go!** All services are now running and communicating.

## � Running in STS IDE (Spring Tool Suite)

This project is fully compatible with **Spring Tool Suite (STS)** IDE, which is specifically designed for Spring Boot development.

### Prerequisites for STS

1. **Download and Install STS:**
   - Download from: https://spring.io/tools
   - Or use Eclipse with Spring Tools 4 plugin

2. **Required Software:**
   - Java 17 JDK installed
   - Maven (usually bundled with STS)
   - Docker Desktop (for Kafka)

### Step 1: Import Projects into STS

**Method A: Import as Maven Projects (Recommended)**

1. Open STS IDE
2. Go to `File` → `Import...`
3. Select `Maven` → `Existing Maven Projects`
4. Click `Next`
5. Click `Browse` and navigate to `c:\Project\Java`
6. STS will detect all three Maven projects:
   - ✅ `user-service/pom.xml`
   - ✅ `order-service/pom.xml`
   - ✅ `notification-service/pom.xml`
7. Make sure all three are checked
8. Click `Finish`
9. Wait for Maven to download dependencies (takes 2-5 minutes first time)

**Method B: Import Individual Projects**

For each service:
1. `File` → `Import` → `Maven` → `Existing Maven Projects`
2. Browse to `user-service`, `order-service`, or `notification-service`
3. Click `Finish`

### Step 2: Configure for Local Development

**Update application.properties files for localhost:**

**order-service/src/main/resources/application.properties:**
```properties
# Change Kafka broker address for local development
spring.kafka.bootstrap-servers=localhost:9092

# Change User Service URL for local development
user.service.url=http://localhost:8081
```

**notification-service/src/main/resources/application.properties:**
```properties
# Change Kafka broker address for local development
spring.kafka.bootstrap-servers=localhost:9092
```

### Step 3: Start Kafka Infrastructure

Before running services in STS, start Kafka and Zookeeper using Docker:

```bash
# Start only Kafka infrastructure
docker-compose up -d zookeeper kafka

# Verify Kafka is running
docker ps | grep kafka
```

### Step 4: Run Services in STS

**Option A: Using Boot Dashboard (Recommended)**

1. Open **Boot Dashboard** view:
   - `Window` → `Show View` → `Other` → `Spring` → `Boot Dashboard`
2. You'll see all three Spring Boot apps listed
3. Right-click each service and select `(Re)start`
4. Start in this order:
   - User Service (wait for it to start)
   - Order Service (wait for it to start)
   - Notification Service

**Option B: Run from Main Class**

1. **Start User Service:**
   - Navigate to `user-service/src/main/java/com/microservices/userservice`
   - Right-click `UserServiceApplication.java`
   - Select `Run As` → `Spring Boot App`
   - Console shows: "Started UserServiceApplication in X seconds"

2. **Start Order Service:**
   - Navigate to `order-service/src/main/java/com/microservices/orderservice`
   - Right-click `OrderServiceApplication.java`
   - Select `Run As` → `Spring Boot App`
   - Console shows: "Started OrderServiceApplication in X seconds"

3. **Start Notification Service:**
   - Navigate to `notification-service/src/main/java/com/microservices/notificationservice`
   - Right-click `NotificationServiceApplication.java`
   - Select `Run As` → `Spring Boot App`
   - Console shows: "Started NotificationServiceApplication in X seconds"

### Step 5: Verify Services

**In STS Console:**
- You should see startup logs for each service
- User Service: `Tomcat started on port(s): 8081`
- Order Service: `Tomcat started on port(s): 8082`
- Notification Service: `Tomcat started on port(s): 8083`

**Test Endpoints:**
```bash
# Test User Service
curl http://localhost:8081/api/users

# Test Order Service
curl http://localhost:8082/api/orders
```

### Using STS Features

**1. Request Mappings View:**
- `Window` → `Show View` → `Other` → `Spring` → `Request Mappings`
- See all REST endpoints for each service

**2. Live Beans Graph:**
- Right-click project → `Spring Tools` → `Open Live Beans Graph`
- Visualize dependency injection

**3. Properties View:**
- View all configuration properties
- `Window` → `Show View` → `Other` → `Spring` → `Properties`

**4. Console Management:**
- Click console dropdown to switch between services
- Color-coded for each running application

**5. Debug Mode:**
- Set breakpoints in any Java file
- Right-click main class → `Debug As` → `Spring Boot App`
- Step through code, inspect variables

### Stopping Services in STS

**From Boot Dashboard:**
- Right-click service → `Stop`

**From Console:**
- Click red square (Terminate) button

**Stop All:**
- Boot Dashboard → Select all → Right-click → `Stop`

### Troubleshooting in STS

**Problem: "Port 8081 already in use"**
```bash
Solution:
1. Stop the service using that port
2. Or change port in application.properties:
   server.port=8091
```

**Problem: Maven dependencies not downloading**
```bash
Solution:
1. Right-click project → Maven → Update Project
2. Check "Force Update of Snapshots/Releases"
3. Click OK
```

**Problem: Cannot resolve imports**
```bash
Solution:
1. Right-click project → Maven → Update Project
2. Project → Clean → Clean all projects
3. Restart STS
```

**Problem: Kafka connection refused**
```bash
Solution:
1. Make sure Kafka is running:
   docker ps | grep kafka
2. Update application.properties:
   spring.kafka.bootstrap-servers=localhost:9092
3. Restart the service
```

### Development Workflow in STS

1. **Make Code Changes:**
   - Edit any Java file
   - STS auto-compiles on save

2. **Restart Service:**
   - Boot Dashboard → Right-click → `Restart`
   - Or use `Ctrl+F11` to rerun

3. **Hot Swap (for minor changes):**
   - In Debug mode, save changes
   - STS attempts hot swap without restart

4. **View Logs:**
   - Console view shows real-time logs
   - Right-click → `Find/Replace` to search logs

5. **Test API:**
   - Use Postman, curl, or STS HTTP Client
   - View responses in console

### Running Full Stack (STS + Docker)

**Hybrid Approach:**

```bash
# Option 1: Services in STS, Kafka in Docker
docker-compose up -d zookeeper kafka
# Then run services in STS

# Option 2: Everything in Docker (for integration testing)
docker-compose up -d
# Then develop and test in STS
```

### STS Project Structure View

```
📁 user-service
  └─ 📁 src/main/java
      └─ 📦 com.microservices.userservice
          ├─ 📄 UserServiceApplication.java [▶ Run As Spring Boot App]
          ├─ 📁 controller
          ├─ 📁 service
          ├─ 📁 repository
          └─ 📁 model
  └─ 📁 src/main/resources
      └─ 📄 application.properties
  └─ 📄 pom.xml

📁 order-service [same structure]
📁 notification-service [same structure]
```

### Tips for STS Development

1. **Use Spring Boot Dashboard** - Manage all services from one place
2. **Enable Auto-Restart** - DevTools dependency for auto-restart on changes
3. **Use Lombok** - Already configured in pom.xml
4. **Check Console Colors** - Each service has different color in console
5. **Use Breakpoints** - Debug mode is powerful for troubleshooting

## �📝 API Endpoints

### User Service (Port 8081)

#### Create User
```bash
POST http://localhost:8081/api/users
Content-Type: application/json

{
  "name": "John Doe",
  "email": "john.doe@example.com",
  "phone": "+1234567890"
}
```

#### Get All Users
```bash
GET http://localhost:8081/api/users
```

#### Get User by ID
```bash
GET http://localhost:8081/api/users/1
```

#### Update User
```bash
PUT http://localhost:8081/api/users/1
Content-Type: application/json

{
  "name": "John Smith",
  "email": "john.smith@example.com",
  "phone": "+1234567890"
}
```

#### Delete User
```bash
DELETE http://localhost:8081/api/users/1
```

### Order Service (Port 8082)

#### Create Order
```bash
POST http://localhost:8082/api/orders
Content-Type: application/json

{
  "userId": 1,
  "productName": "Laptop",
  "quantity": 2,
  "totalAmount": 2000.00
}
```

**Response:**
```json
{
  "id": 1,
  "userId": 1,
  "productName": "Laptop",
  "quantity": 2,
  "totalAmount": 2000.0,
  "status": "PENDING",
  "createdAt": "2026-01-27T08:20:16.879587"
}
```

**What happens:**
- Order Service validates the userId by calling User Service REST API
- Order is saved to database
- Kafka event is published to `order-events` topic
- Notification Service receives and processes the event

#### Get All Orders
```bash
GET http://localhost:8082/api/orders
```

#### Get Order by ID
```bash
GET http://localhost:8082/api/orders/1
```

#### Get Orders by User ID
```bash
GET http://localhost:8082/api/orders/user/1
```

### Notification Service (Port 8083)

The Notification Service doesn't expose REST endpoints. It's an event-driven consumer that:
- Listens to the `order-events` Kafka topic
- Processes order creation and status update events
- Logs notification messages to console

**To view notifications:**
```bash
docker logs notification-service --tail 50 -f
```

## 🧪 Testing the Complete Flow

Follow these steps to test the entire microservices architecture:

### Test 1: Create a User

**PowerShell:**
```powershell
Invoke-RestMethod -Method POST -Uri "http://localhost:8081/api/users" `
  -Body '{"name":"John Doe","email":"john@example.com","phone":"+1234567890"}' `
  -ContentType "application/json"
```

**Bash/curl:**
```bash
curl -X POST http://localhost:8081/api/users \
  -H "Content-Type: application/json" \
  -d '{"name":"John Doe","email":"john@example.com","phone":"+1234567890"}'
```

**Expected Response:**
```json
{
  "id": 1,
  "name": "John Doe",
  "email": "john@example.com",
  "phone": "+1234567890"
}
```

### Test 2: Create an Order (Triggers REST + Kafka)

**PowerShell:**
```powershell
Invoke-RestMethod -Method POST -Uri "http://localhost:8082/api/orders" `
  -Body '{"userId":1,"productName":"MacBook Pro","quantity":1,"totalAmount":2500.0}' `
  -ContentType "application/json"
```

**Bash/curl:**
```bash
curl -X POST http://localhost:8082/api/orders \
  -H "Content-Type: application/json" \
  -d '{"userId":1,"productName":"MacBook Pro","quantity":1,"totalAmount":2500.0}'
```

**Expected Response:**
```json
{
  "id": 1,
  "userId": 1,
  "productName": "MacBook Pro",
  "quantity": 1,
  "totalAmount": 2500.0,
  "status": "PENDING",
  "createdAt": "2026-01-27T08:20:16.879587"
}
```

**What happens internally:**
1. Order Service receives the request
2. Order Service calls User Service via REST API to fetch user details
3. Order is saved to Order Service database
4. Order Service publishes event to Kafka topic `order-events`
5. Notification Service consumes the event from Kafka
6. Notification Service processes and logs the notification

### Test 3: Check Notification Service Logs

```bash
# View last 20 lines of notification service logs
docker logs notification-service --tail 20
```

**Expected Output:**
```
=================================================
📧 NOTIFICATION SERVICE - New Order Event Received
=================================================
Order ID: 1
User ID: 1
Product: MacBook Pro
Quantity: 1
Total Amount: $2500.0
Status: PENDING
Message: Order created for user: John Doe
=================================================
✅ Notification sent: Dear User 1, your order #1 for MacBook Pro has been PENDING. Total: $2500.00
```

### Test 4: View All Users

**PowerShell:**
```powershell
Invoke-RestMethod -Uri "http://localhost:8081/api/users"
```

**Bash/curl:**
```bash
curl http://localhost:8081/api/users
```

### Test 5: View All Orders

**PowerShell:**
```powershell
Invoke-RestMethod -Uri "http://localhost:8082/api/orders"
```

**Bash/curl:**
```bash
curl http://localhost:8082/api/orders
```

### Test 6: Get Specific User

**PowerShell:**
```powershell
Invoke-RestMethod -Uri "http://localhost:8081/api/users/1"
```

**Bash/curl:**
```bash
curl http://localhost:8081/api/users/1
```

### Test 7: Update User

**PowerShell:**
```powershell
Invoke-RestMethod -Method PUT -Uri "http://localhost:8081/api/users/1" `
  -Body '{"name":"John Smith","email":"john.smith@example.com","phone":"+1234567890"}' `
  -ContentType "application/json"
```

**Bash/curl:**
```bash
curl -X PUT http://localhost:8081/api/users/1 \
  -H "Content-Type: application/json" \
  -d '{"name":"John Smith","email":"john.smith@example.com","phone":"+1234567890"}'
```

### Automated Test Script

We've provided a PowerShell test script for convenience:

```powershell
# Run all tests automatically
.\test-services.ps1
```

This script will:
- ✅ Check if all services are running
- ✅ Create test users
- ✅ Create test orders
- ✅ Verify REST API communication
- ✅ Verify Kafka messaging
- ✅ Display results in a formatted table

## 🔍 Key Features Demonstrated

### ✅ REST API Communication
- Order Service calls User Service via RestTemplate to verify user existence
- RESTful endpoints following best practices

### ✅ Kafka Event-Driven Architecture
- Order Service publishes order events to Kafka
- Notification Service consumes events asynchronously
- Loose coupling between services

### ✅ Docker Containerization
- Each service has its own Dockerfile
- Multi-stage builds for optimized images
- Docker Compose orchestrates all services

### ✅ Service Independence
- Each service has its own database (H2)
- Services can be scaled independently
- Failure isolation

## 🛑 Managing the Services

### Stop All Services

```bash
# Stop all services (keeps data)
docker-compose stop

# Stop and remove containers (removes data)
docker-compose down

# Stop and remove everything including volumes
docker-compose down -v
```

### Start Stopped Services

```bash
# Start existing containers
docker-compose start

# Start services (creates new containers if needed)
docker-compose up -d
```

### Restart Services

```bash
# Restart all services
docker-compose restart

# Restart specific service
docker-compose restart user-service
docker-compose restart order-service
docker-compose restart notification-service
```

### Rebuild After Code Changes

```bash
# Rebuild and restart all services
docker-compose up --build -d

# Rebuild specific service
docker-compose build user-service
docker-compose up -d user-service
```

## 📊 Monitoring and Debugging

### View Service Logs

```bash
# View logs for all services (live)
docker-compose logs -f

# View logs for specific service
docker logs user-service
docker logs order-service
docker logs notification-service --tail 50 -f

# View Kafka logs
docker logs kafka --tail 100
```

### Check Container Status

```bash
# List running containers
docker ps

# Detailed container information
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"

# Check container health
docker inspect user-service | grep -A 5 Health
```

### Check Service Health

**User Service Health:**
```bash
curl http://localhost:8081/api/users
# Should return [] or list of users
```

**Order Service Health:**
```bash
curl http://localhost:8082/api/orders
# Should return [] or list of orders
```

**Kafka Topics:**
```bash
# List all Kafka topics
docker exec -it kafka kafka-topics --bootstrap-server localhost:9092 --list

# Describe order-events topic
docker exec -it kafka kafka-topics --bootstrap-server localhost:9092 --describe --topic order-events

# Read messages from topic (for debugging)
docker exec -it kafka kafka-console-consumer --bootstrap-server localhost:9092 --topic order-events --from-beginning
```

### Access H2 Database Console

Each service has an H2 web console for database inspection:

**User Service Database:**
```
URL: http://localhost:8081/h2-console
JDBC URL: jdbc:h2:mem:userdb
Username: sa
Password: (leave empty)
```

**Order Service Database:**
```
URL: http://localhost:8082/h2-console
JDBC URL: jdbc:h2:mem:orderdb
Username: sa
Password: (leave empty)
```

### Monitor Resource Usage

```bash
# View container resource usage
docker stats

# View specific container stats
docker stats user-service order-service notification-service
```

## 🐛 Troubleshooting

### Problem: Docker containers won't start

**Solution:**
```bash
# 1. Check if Docker Desktop is running
docker --version

# 2. Check port availability
netstat -ano | findstr "8081"
netstat -ano | findstr "8082"
netstat -ano | findstr "9092"

# 3. Clean up and restart
docker-compose down -v
docker system prune -f
docker-compose up --build -d
```

### Problem: "Port already in use" error

**Solution:**
```bash
# Find process using the port (Windows)
netstat -ano | findstr "8081"
taskkill /PID <process_id> /F

# Find process using the port (Linux/Mac)
lsof -i :8081
kill -9 <process_id>

# Or change the port in docker-compose.yml
```

### Problem: Kafka connection issues

**Symptoms:** Notification Service shows "Connection to node -1 could not be established"

**Solution:**
```bash
# 1. Wait 30-60 seconds after starting docker-compose
# Kafka takes time to initialize

# 2. Check Kafka is running
docker ps | grep kafka

# 3. Check Kafka logs
docker logs kafka --tail 50

# 4. Restart Kafka services
docker-compose restart zookeeper kafka
docker-compose restart notification-service
```

### Problem: Order creation fails with 400 Bad Request

**Cause:** User doesn't exist or User Service is down

**Solution:**
```bash
# 1. Verify User Service is running
curl http://localhost:8081/api/users

# 2. Create a user first
curl -X POST http://localhost:8081/api/users \
  -H "Content-Type: application/json" \
  -d '{"name":"Test User","email":"test@example.com","phone":"+1234567890"}'

# 3. Then create the order with the returned user ID
```

### Problem: Notification Service not receiving events

**Symptoms:** No logs in notification-service when creating orders

**Solution:**
```bash
# 1. Check if Kafka topic exists
docker exec -it kafka kafka-topics --bootstrap-server localhost:9092 --list

# 2. Check notification service logs for errors
docker logs notification-service --tail 100

# 3. Verify Kafka consumer is connected
docker logs notification-service | grep "Successfully joined group"

# 4. Restart notification service
docker-compose restart notification-service
```

### Problem: Services show "unhealthy" status

**Solution:**
```bash
# 1. Check service logs
docker logs <service-name>

# 2. Wait 1-2 minutes for health checks to pass
# Services may show unhealthy during startup

# 3. Test endpoint manually
curl http://localhost:8081/api/users
curl http://localhost:8082/api/orders

# 4. If still unhealthy, restart service
docker-compose restart <service-name>
```

### Problem: Out of memory errors

**Solution:**
```bash
# 1. Check Docker Desktop memory settings
# Docker Desktop > Settings > Resources > Memory (increase to 8GB+)

# 2. Check memory usage
docker stats

# 3. Clean up unused resources
docker system prune -a --volumes
```

### Problem: Slow build times

**Solution:**
```bash
# 1. Use cached layers
docker-compose build

# 2. Build specific service only
docker-compose build user-service

# 3. Use parallel builds
docker-compose build --parallel
```

### Problem: Cannot connect to Docker daemon

**Windows Solution:**
```powershell
# Start Docker Desktop from Start Menu
# Or restart Docker service
Restart-Service docker
```

**Linux Solution:**
```bash
# Start Docker service
sudo systemctl start docker
sudo systemctl enable docker

# Add user to docker group (logout/login required)
sudo usermod -aG docker $USER
```

### Getting Help

If you encounter issues not covered here:

1. **Check logs first:**
   ```bash
   docker-compose logs -f
   ```

2. **Verify all services are running:**
   ```bash
   docker ps
   ```

3. **Check application.properties** files for configuration issues

4. **Review COMMENTS_SUMMARY.md** for architecture details

5. **Clean slate restart:**
   ```bash
   docker-compose down -v
   docker system prune -f
   docker-compose up --build -d
   ```

## 📦 Project Files and Structure

```
Java/
├── user-service/                      # User Management Microservice
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/microservices/userservice/
│   │   │   │   ├── UserServiceApplication.java
│   │   │   │   ├── controller/
│   │   │   │   │   └── UserController.java       # REST endpoints
│   │   │   │   ├── service/
│   │   │   │   │   └── UserService.java          # Business logic
│   │   │   │   ├── repository/
│   │   │   │   │   └── UserRepository.java       # Data access
│   │   │   │   └── entity/
│   │   │   │       └── User.java                 # JPA entity
│   │   │   └── resources/
│   │   │       └── application.properties         # Configuration
│   ├── Dockerfile                                 # Multi-stage build
│   └── pom.xml                                    # Maven dependencies
│
├── order-service/                     # Order Management Microservice
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/microservices/orderservice/
│   │   │   │   ├── OrderServiceApplication.java
│   │   │   │   ├── controller/
│   │   │   │   │   └── OrderController.java
│   │   │   │   ├── service/
│   │   │   │   │   └── OrderService.java         # REST + Kafka logic
│   │   │   │   ├── repository/
│   │   │   │   │   └── OrderRepository.java
│   │   │   │   ├── entity/
│   │   │   │   │   └── Order.java
│   │   │   │   ├── dto/
│   │   │   │   │   ├── OrderEvent.java           # Kafka DTO
│   │   │   │   │   └── UserDTO.java              # REST DTO
│   │   │   │   └── kafka/
│   │   │   │       ├── KafkaProducerService.java
│   │   │   │       └── KafkaProducerConfig.java
│   │   │   └── resources/
│   │   │       └── application.properties
│   ├── Dockerfile
│   └── pom.xml
│
├── notification-service/              # Event-Driven Notification Service
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/microservices/notificationservice/
│   │   │   │   ├── NotificationServiceApplication.java
│   │   │   │   ├── kafka/
│   │   │   │   │   ├── KafkaConsumerService.java # Event consumer
│   │   │   │   │   └── KafkaConsumerConfig.java  # Consumer config
│   │   │   │   └── dto/
│   │   │   │       └── OrderEvent.java
│   │   │   └── resources/
│   │   │       └── application.properties
│   ├── Dockerfile
│   └── pom.xml
│
├── docker-compose.yml                 # Orchestrates all services
├── README.md                          # This file
├── COMMENTS_SUMMARY.md                # Documentation index
├── VERIFICATION_REPORT.md             # Test results
├── test-services.ps1                  # Automated test script
└── .gitignore                         # Git ignore rules
```

### Key Configuration Files

**docker-compose.yml** - Defines:
- 5 services (Zookeeper, Kafka, User, Order, Notification)
- Network configuration
- Health checks
- Dependencies
- Port mappings

**application.properties** - Each service has its own with:
- Server port
- Database configuration (H2)
- Kafka settings (producer/consumer)
- Service URLs

**Dockerfiles** - Multi-stage builds:
- Stage 1: Build with Maven
- Stage 2: Run with JRE (smaller image)

## 🔄 Development Workflow

### Making Code Changes

1. **Edit source code** in any service

2. **Rebuild specific service:**
   ```bash
   docker-compose build <service-name>
   docker-compose up -d <service-name>
   ```

3. **Test changes:**
   ```bash
   docker logs <service-name>
   ```

### Adding New Endpoints

1. Add method to Controller class
2. Update Service layer if needed
3. Rebuild and test
4. Update this README with new endpoint documentation

### Testing Locally (without Docker)

```bash
# Start Kafka infrastructure only
docker-compose up -d zookeeper kafka

# Run services locally with Maven
cd user-service
mvn spring-boot:run

# In another terminal
cd order-service
mvn spring-boot:run

# In another terminal
cd notification-service
mvn spring-boot:run
```

**Note:** Update `application.properties` to use `localhost` instead of service names when running locally.

## 🎯 Future Enhancements

This project serves as a foundation. Here are suggested improvements:

### Infrastructure
- [ ] **API Gateway** - Single entry point using Spring Cloud Gateway
- [ ] **Service Discovery** - Dynamic service registration with Eureka
- [ ] **Config Server** - Centralized configuration management
- [ ] **Load Balancer** - Nginx or Spring Cloud LoadBalancer

### Resilience
- [ ] **Circuit Breakers** - Resilience4j for fault tolerance
- [ ] **Retry Mechanisms** - Automatic retry with exponential backoff
- [ ] **Rate Limiting** - Prevent API abuse
- [ ] **Bulkhead Pattern** - Resource isolation

### Observability
- [ ] **Distributed Tracing** - Zipkin or Jaeger integration
- [ ] **Centralized Logging** - ELK Stack (Elasticsearch, Logstash, Kibana)
- [ ] **Metrics** - Prometheus + Grafana dashboards
- [ ] **Health Checks** - Spring Boot Actuator endpoints

### Security
- [ ] **Authentication** - JWT token-based auth
- [ ] **Authorization** - Role-based access control (RBAC)
- [ ] **API Keys** - For external service access
- [ ] **HTTPS/TLS** - Secure communication
- [ ] **Secret Management** - HashiCorp Vault integration

### Data Management
- [ ] **PostgreSQL/MySQL** - Replace H2 with production database
- [ ] **Database Migrations** - Flyway or Liquibase
- [ ] **Caching** - Redis for performance
- [ ] **Data Validation** - JSR-303 Bean Validation

### Testing
- [ ] **Unit Tests** - JUnit 5 + Mockito
- [ ] **Integration Tests** - TestContainers
- [ ] **API Tests** - RestAssured
- [ ] **Contract Tests** - Pact or Spring Cloud Contract
- [ ] **Performance Tests** - JMeter or Gatling

### Deployment
- [ ] **Kubernetes** - Container orchestration
- [ ] **Helm Charts** - K8s package management
- [ ] **CI/CD Pipeline** - GitHub Actions, Jenkins, or GitLab CI
- [ ] **Blue-Green Deployment** - Zero-downtime releases

### Advanced Features
- [ ] **Saga Pattern** - Distributed transactions
- [ ] **Event Sourcing** - Audit trail and state rebuilding
- [ ] **CQRS** - Command Query Responsibility Segregation
- [ ] **WebSockets** - Real-time notifications
- [ ] **GraphQL API** - Alternative to REST

## 📚 Learning Resources

### Spring Boot
- [Spring Boot Documentation](https://spring.io/projects/spring-boot)
- [Spring Data JPA Guide](https://spring.io/guides/gs/accessing-data-jpa/)
- [Spring REST Tutorial](https://spring.io/guides/gs/rest-service/)

### Apache Kafka
- [Kafka Documentation](https://kafka.apache.org/documentation/)
- [Spring Kafka Guide](https://spring.io/projects/spring-kafka)
- [Kafka Tutorial by Confluent](https://kafka.apache.org/quickstart)

### Microservices
- [Microservices Patterns by Chris Richardson](https://microservices.io/)
- [Spring Cloud Documentation](https://spring.io/projects/spring-cloud)
- [12 Factor App Methodology](https://12factor.net/)

### Docker
- [Docker Get Started Guide](https://docs.docker.com/get-started/)
- [Docker Compose Documentation](https://docs.docker.com/compose/)
- [Best Practices for Dockerfiles](https://docs.docker.com/develop/dev-best-practices/)

## 📄 License

This project is created for educational purposes and is free to use, modify, and distribute.

## 👥 Contributing

Contributions are welcome! To contribute:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📞 Support

If you have questions or need help:

1. Check the **Troubleshooting** section above
2. Review **COMMENTS_SUMMARY.md** for code documentation
3. Check service logs: `docker-compose logs -f`
4. Open an issue on the GitHub repository

## ✅ Project Status

- ✅ All microservices implemented
- ✅ Docker containerization complete
- ✅ REST API communication working
- ✅ Kafka messaging working
- ✅ Comprehensive code comments added
- ✅ Documentation complete
- ✅ Health checks implemented
- ✅ Ready for production enhancements

---

## 🚀 Quick Command Reference

```bash
# Start everything
docker-compose up -d

# View logs
docker-compose logs -f

# Stop everything
docker-compose down

# Rebuild after changes
docker-compose up --build -d

# Check status
docker ps

# Test services
curl http://localhost:8081/api/users
curl http://localhost:8082/api/orders

# Clean restart
docker-compose down -v && docker-compose up --build -d
```

---

**Built with ❤️ using Spring Boot, Kafka, and Docker**

*Last Updated: January 27, 2026*
