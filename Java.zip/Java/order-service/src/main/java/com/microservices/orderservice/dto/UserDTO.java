package com.microservices.orderservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * UserDTO Data Transfer Object
 * 
 * This class represents user data received from the User Service.
 * It's used when Order Service calls User Service via REST API to verify users.
 * 
 * Purpose:
 * - Receives and deserializes JSON response from User Service
 * - Decouples Order Service from User Service's internal User entity
 * - Contains only the fields needed by Order Service
 * 
 * Used in:
 * - OrderService.createOrder() to verify user exists before creating order
 */
@Data  // Lombok: Generates getters, setters, toString, equals, and hashCode
@NoArgsConstructor  // Lombok: Required for JSON deserialization
@AllArgsConstructor  // Lombok: Generates constructor with all fields
public class UserDTO {
    private Long id;  // User's unique identifier
    private String name;  // User's full name
    private String email;  // User's email address
    private String phone;  // User's phone number
}
