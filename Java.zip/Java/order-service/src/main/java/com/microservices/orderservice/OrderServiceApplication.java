package com.microservices.orderservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

/**
 * Order Service Application - Main entry point
 * 
 * This is the main Spring Boot application class for the Order Service microservice.
 * It manages order-related operations and communicates with:
 * - User Service (via REST API using RestTemplate)
 * - Kafka (for publishing order events)
 * 
 * Port: 8082
 * Database: H2 in-memory database
 * 
 * @author Microservices Team
 * @version 1.0.0
 */
@SpringBootApplication  // Enables auto-configuration, component scanning, and configuration
public class OrderServiceApplication {
    
    /**
     * Main method - Application entry point
     * Starts the Spring Boot application and initializes all components
     * 
     * @param args Command line arguments
     */
    public static void main(String[] args) {
        SpringApplication.run(OrderServiceApplication.class, args);
    }
    
    /**
     * RestTemplate Bean Configuration
     * 
     * RestTemplate is used for making HTTP requests to other microservices.
     * In this case, it's used to call the User Service REST API.
     * 
     * @return RestTemplate instance for inter-service communication
     */
    @Bean  // Marks this method as a bean definition
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}
