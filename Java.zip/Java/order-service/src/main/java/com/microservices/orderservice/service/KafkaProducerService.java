package com.microservices.orderservice.service;

import com.microservices.orderservice.dto.OrderEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

/**
 * Kafka Producer Service - Message Publishing
 * 
 * This service is responsible for publishing order events to Kafka.
 * It uses Spring Kafka's KafkaTemplate to send messages to the configured topic.
 * 
 * Flow:
 * 1. OrderService creates/updates an order
 * 2. OrderService calls this service to publish an event
 * 3. Event is serialized to JSON and sent to Kafka topic
 * 4. Notification Service (consumer) receives and processes the event
 * 
 * Benefits:
 * - Asynchronous communication between services
 * - Decouples Order Service from Notification Service
 * - Reliable message delivery through Kafka
 */
@Service  // Marks this as a Spring service component
public class KafkaProducerService {
    
    /**
     * Kafka topic name from application.properties
     * Default: "order-events"
     */
    @Value("${spring.kafka.topic.order-events}")  // Injects value from config
    private String orderEventsTopic;
    
    /**
     * KafkaTemplate for sending messages to Kafka
     * Automatically configured by Spring Boot
     */
    @Autowired  // Dependency injection
    private KafkaTemplate<String, OrderEvent> kafkaTemplate;
    
    /**
     * Publish an order event to Kafka
     * 
     * This method sends an OrderEvent to the Kafka topic.
     * The event will be consumed by the Notification Service.
     * 
     * @param orderEvent The order event to publish
     */
    public void sendOrderEvent(OrderEvent orderEvent) {
        // Send message to Kafka topic
        // Key is null, value is the OrderEvent (will be serialized to JSON)
        kafkaTemplate.send(orderEventsTopic, orderEvent);
        
        // Log the event for debugging
        System.out.println("Order event sent to Kafka: " + orderEvent);
    }
}
