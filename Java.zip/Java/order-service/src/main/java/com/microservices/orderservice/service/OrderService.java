package com.microservices.orderservice.service;

import com.microservices.orderservice.dto.OrderEvent;
import com.microservices.orderservice.dto.UserDTO;
import com.microservices.orderservice.model.Order;
import com.microservices.orderservice.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Optional;

/**
 * Order Service - Business Logic Layer
 * 
 * This service orchestrates order management operations and coordinates
 * communication with other microservices.
 * 
 * Responsibilities:
 * 1. Validate orders and business rules
 * 2. Call User Service via REST API to verify users exist
 * 3. Manage order persistence (database operations)
 * 4. Publish order events to Kafka for notification service
 * 
 * Communication Patterns:
 * - REST API: Synchronous call to User Service (RestTemplate)
 * - Kafka: Asynchronous event publishing to Notification Service
 */
@Service  // Marks this as a Spring service component
public class OrderService {
    
    @Autowired  // Dependency injection for database operations
    private OrderRepository orderRepository;
    
    @Autowired  // Dependency injection for REST API calls
    private RestTemplate restTemplate;
    
    @Autowired  // Dependency injection for Kafka message publishing
    private KafkaProducerService kafkaProducerService;
    
    /**
     * User Service base URL from application.properties
     * Example: http://localhost:8081 or http://user-service:8081
     */
    @Value("${user.service.url}")
    private String userServiceUrl;
    
    /**
     * Retrieve all orders from the database
     * 
     * @return List of all orders
     */
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }
    
    /**
     * Find a specific order by its ID
     * 
     * @param id The order's unique identifier
     * @return Optional containing the order if found, empty otherwise
     */
    public Optional<Order> getOrderById(Long id) {
        return orderRepository.findById(id);
    }
    
    /**
     * Retrieve all orders for a specific user
     * 
     * @param userId The user's unique identifier
     * @return List of orders belonging to the user
     */
    public List<Order> getOrdersByUserId(Long userId) {
        return orderRepository.findByUserId(userId);
    }
    
    /**
     * Create a new order
     * 
     * This method demonstrates inter-service communication in microservices:
     * 1. Validates user exists by calling User Service via REST API
     * 2. Saves the order to the database
     * 3. Publishes an order event to Kafka for asynchronous processing
     * 
     * Flow:
     * Order Service --> (REST API) --> User Service (verify user)
     * Order Service --> (Save) --> Database
     * Order Service --> (Kafka Event) --> Notification Service
     * 
     * @param order The order to create
     * @return The created order with generated ID
     * @throws RuntimeException if user not found or communication fails
     */
    public Order createOrder(Order order) {
        // Step 1: Verify user exists by calling User Service via REST API
        try {
            // Build URL: http://user-service:8081/api/users/{userId}
            String url = userServiceUrl + "/api/users/" + order.getUserId();
            
            // Make synchronous REST call to User Service
            // RestTemplate automatically deserializes JSON response to UserDTO
            UserDTO user = restTemplate.getForObject(url, UserDTO.class);
            
            // Check if user was found
            if (user == null) {
                throw new RuntimeException("User not found with id: " + order.getUserId());
            }
            
            // Step 2: Save order to database
            Order savedOrder = orderRepository.save(order);
            
            // Step 3: Publish order event to Kafka
            // Create event with order details and user information
            OrderEvent orderEvent = new OrderEvent(
                savedOrder.getId(),
                savedOrder.getUserId(),
                savedOrder.getProductName(),
                savedOrder.getQuantity(),
                savedOrder.getTotalAmount(),
                savedOrder.getStatus(),
                "Order created for user: " + user.getName()  // Include user name from REST call
            );
            
            // Send event to Kafka (asynchronous)
            kafkaProducerService.sendOrderEvent(orderEvent);
            
            return savedOrder;
            
        } catch (Exception e) {
            // Handle REST call failures, network issues, etc.
            throw new RuntimeException("Failed to create order: " + e.getMessage());
        }
    }
    
    /**
     * Update an order's status
     * 
     * Updates the order status and publishes a Kafka event to notify
     * other services (like Notification Service) about the status change.
     * 
     * Common Status Values:
     * - PENDING: Order placed, awaiting processing
     * - PROCESSING: Order is being prepared
     * - SHIPPED: Order has been shipped
     * - DELIVERED: Order delivered to customer
     * - CANCELLED: Order was cancelled
     * 
     * @param id The order ID to update
     * @param status The new status value
     * @return The updated order
     * @throws RuntimeException if order not found
     */
    public Order updateOrderStatus(Long id, String status) {
        // Find the order or throw exception
        Order order = orderRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Order not found with id: " + id));
        
        // Update the status
        order.setStatus(status);
        Order updatedOrder = orderRepository.save(order);
        
        // Publish status update event to Kafka
        OrderEvent orderEvent = new OrderEvent(
            updatedOrder.getId(),
            updatedOrder.getUserId(),
            updatedOrder.getProductName(),
            updatedOrder.getQuantity(),
            updatedOrder.getTotalAmount(),
            updatedOrder.getStatus(),
            "Order status updated to: " + status  // Status change message
        );
        kafkaProducerService.sendOrderEvent(orderEvent);
        
        return updatedOrder;
    }
}
