package com.microservices.orderservice.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Order Entity - Represents an order in the system
 * 
 * This entity is mapped to the "orders" table in the H2 database.
 * Contains order information including user reference, product details, and status.
 * 
 * Relationships:
 * - References User Service via userId (no direct JPA relationship - microservices pattern)
 * - Each order is associated with a user from the User Service
 * 
 * Lombok annotations reduce boilerplate code:
 * - @Data: Generates getters, setters, toString, equals, and hashCode
 * - @NoArgsConstructor: Generates no-args constructor
 * - @AllArgsConstructor: Generates constructor with all fields
 */
@Entity  // Marks this class as a JPA entity
@Table(name = "orders")  // Maps to "orders" table in database
@Data  // Lombok: Generates getters, setters, toString, equals, and hashCode
@NoArgsConstructor  // Lombok: Generates constructor with no parameters
@AllArgsConstructor  // Lombok: Generates constructor with all parameters
public class Order {
    
    @Id  // Marks this field as the primary key
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // Auto-generates ID
    private Long id;  // Unique identifier for the order
    
    private Long userId;  // Reference to user in User Service (no direct FK)
    private String productName;  // Name of the product ordered
    private Integer quantity;  // Number of items ordered
    private Double totalAmount;  // Total price for the order
    private String status;  // Order status: PENDING, SHIPPED, DELIVERED, etc.
    
    @Column(name = "created_at")  // Maps to "created_at" column
    private LocalDateTime createdAt;  // Timestamp when order was created
    
    /**
     * Pre-persist callback
     * This method is automatically called before the entity is saved to the database.
     * Sets default values for new orders.
     */
    @PrePersist  // JPA lifecycle callback - runs before insert
    protected void onCreate() {
        createdAt = LocalDateTime.now();  // Set creation timestamp
        if (status == null) {
            status = "PENDING";  // Default status for new orders
        }
    }
}
