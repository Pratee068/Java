package com.microservices.orderservice.repository;

import com.microservices.orderservice.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Order Repository - Data Access Layer
 * 
 * This interface provides database operations for Order entities.
 * By extending JpaRepository, it automatically gets CRUD operations:
 * - save(): Create or update an order
 * - findById(): Find order by ID
 * - findAll(): Get all orders
 * - deleteById(): Delete order by ID
 * 
 * Custom Methods:
 * - findByUserId(): Find all orders for a specific user
 *   (Spring Data JPA automatically implements this based on method name)
 * 
 * Spring Data JPA generates the implementation at runtime!
 */
@Repository  // Marks this as a Spring Data repository
public interface OrderRepository extends JpaRepository<Order, Long> {
    
    /**
     * Find all orders for a specific user
     * 
     * Method naming convention allows Spring Data JPA to automatically
     * generate the query: SELECT * FROM orders WHERE user_id = ?
     * 
     * @param userId The user's unique identifier
     * @return List of orders belonging to the user
     */
    List<Order> findByUserId(Long userId);
}
