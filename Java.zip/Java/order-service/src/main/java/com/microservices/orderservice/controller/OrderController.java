package com.microservices.orderservice.controller;

import com.microservices.orderservice.model.Order;
import com.microservices.orderservice.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Order Controller - REST API Endpoints
 * 
 * This controller exposes REST API endpoints for order management.
 * All endpoints are prefixed with /api/orders
 * 
 * Available Endpoints:
 * - GET    /api/orders              - Get all orders
 * - GET    /api/orders/{id}         - Get order by ID
 * - GET    /api/orders/user/{userId} - Get orders for specific user
 * - POST   /api/orders              - Create new order (triggers REST call + Kafka event)
 * - PATCH  /api/orders/{id}/status  - Update order status (triggers Kafka event)
 * 
 * This controller demonstrates microservices communication:
 * - Creating order triggers REST API call to User Service
 * - Creating/updating order publishes event to Kafka
 */
@RestController  // Combines @Controller and @ResponseBody
@RequestMapping("/api/orders")  // Base path for all endpoints
public class OrderController {
    
    @Autowired  // Inject OrderService dependency
    private OrderService orderService;
    
    /**
     * GET /api/orders
     * Retrieve all orders from the database
     * 
     * @return 200 OK with list of all orders
     */
    @GetMapping
    public ResponseEntity<List<Order>> getAllOrders() {
        return ResponseEntity.ok(orderService.getAllOrders());
    }
    
    /**
     * GET /api/orders/{id}
     * Retrieve a specific order by its ID
     * 
     * @param id The order's unique identifier from URL path
     * @return 200 OK with order data if found, 404 NOT FOUND otherwise
     */
    @GetMapping("/{id}")
    public ResponseEntity<Order> getOrderById(@PathVariable Long id) {
        return orderService.getOrderById(id)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }
    
    /**
     * GET /api/orders/user/{userId}
     * Retrieve all orders for a specific user
     * 
     * @param userId The user's unique identifier
     * @return 200 OK with list of user's orders
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Order>> getOrdersByUserId(@PathVariable Long userId) {
        return ResponseEntity.ok(orderService.getOrdersByUserId(userId));
    }
    
    /**
     * POST /api/orders
     * Create a new order
     * 
     * This endpoint demonstrates microservices communication:
     * 1. Calls User Service via REST API to verify user exists
     * 2. Creates order in database
     * 3. Publishes order event to Kafka
     * 
     * @param order Order data from request body (JSON)
     * @return 201 CREATED with created order, 400 BAD REQUEST if validation fails
     */
    @PostMapping
    public ResponseEntity<Order> createOrder(@RequestBody Order order) {
        try {
            Order createdOrder = orderService.createOrder(order);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdOrder);
        } catch (RuntimeException e) {
            // User not found or service communication failed
            return ResponseEntity.badRequest().build();
        }
    }
    
    /**
     * PATCH /api/orders/{id}/status
     * Update an order's status
     * 
     * This triggers a Kafka event to notify other services (Notification Service)
     * about the status change.
     * 
     * Example: PATCH /api/orders/1/status?status=SHIPPED
     * 
     * @param id The order ID to update
     * @param status The new status (query parameter)
     * @return 200 OK with updated order, 404 NOT FOUND if order doesn't exist
     */
    @PatchMapping("/{id}/status")
    public ResponseEntity<Order> updateOrderStatus(
            @PathVariable Long id, 
            @RequestParam String status) {
        try {
            Order updatedOrder = orderService.updateOrderStatus(id, status);
            return ResponseEntity.ok(updatedOrder);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
