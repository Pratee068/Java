package com.microservices.orderservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * OrderEvent Data Transfer Object (DTO)
 * 
 * This class represents an order event that is published to Kafka.
 * It's a simplified version of the Order entity designed for messaging.
 * 
 * Purpose:
 * - Decouples the internal Order entity from the message format
 * - Can be serialized to JSON for Kafka messaging
 * - Contains only the necessary information for event consumers
 * 
 * Events are published when:
 * - A new order is created
 * - An order status is updated
 * - Order information changes
 */
@Data  // Lombok: Generates getters, setters, toString, equals, and hashCode
@NoArgsConstructor  // Lombok: Required for JSON deserialization
@AllArgsConstructor  // Lombok: Generates constructor with all fields
public class OrderEvent {
    private Long orderId;  // ID of the order
    private Long userId;  // ID of the user who placed the order
    private String productName;  // Product name
    private Integer quantity;  // Quantity ordered
    private Double totalAmount;  // Total order amount
    private String status;  // Current order status
    private String message;  // Human-readable message about the event
}
