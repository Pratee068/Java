package com.microservices.orderservice.config;

import com.microservices.orderservice.dto.OrderEvent;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;

import java.util.HashMap;
import java.util.Map;

/**
 * Kafka Producer Configuration
 * 
 * This configuration class sets up Kafka producer beans for publishing messages.
 * It configures:
 * - Kafka broker connection
 * - Serialization (converts Java objects to bytes for transmission)
 * - Producer settings for reliability and performance
 * 
 * Key Components:
 * - ProducerFactory: Creates Kafka producer instances
 * - KafkaTemplate: High-level API for sending messages
 * - Serializers: Convert objects to JSON for transmission
 */
@Configuration  // Marks this as a Spring configuration class
public class KafkaProducerConfig {
    
    /**
     * Kafka broker address from application.properties
     * Format: host:port (e.g., localhost:9092)
     */
    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;
    
    /**
     * Producer Factory Bean
     * 
     * Creates and configures the Kafka producer factory.
     * This factory is used by KafkaTemplate to create producer instances.
     * 
     * Configuration:
     * - BOOTSTRAP_SERVERS: Kafka broker addresses
     * - KEY_SERIALIZER: Serializes message keys to String
     * - VALUE_SERIALIZER: Serializes message values to JSON
     * 
     * @return ProducerFactory configured for OrderEvent messages
     */
    @Bean
    public ProducerFactory<String, OrderEvent> producerFactory() {
        Map<String, Object> config = new HashMap<>();
        
        // Kafka broker address
        config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        
        // Serialize message keys as strings
        config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        
        // Serialize message values as JSON
        config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
        
        return new DefaultKafkaProducerFactory<>(config);
    }
    
    /**
     * Kafka Template Bean
     * 
     * KafkaTemplate provides a high-level API for sending messages to Kafka.
     * It simplifies producer operations and handles serialization automatically.
     * 
     * Usage:
     * - kafkaTemplate.send(topic, message)
     * - Automatically serializes OrderEvent to JSON
     * - Handles connection management
     * 
     * @return KafkaTemplate configured for OrderEvent messages
     */
    @Bean
    public KafkaTemplate<String, OrderEvent> kafkaTemplate() {
        return new KafkaTemplate<>(producerFactory());
    }
}
