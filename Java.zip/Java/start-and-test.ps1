# Wait for build to complete and start services
Write-Host "Waiting for docker-compose build to complete..." -ForegroundColor Yellow
Start-Sleep -Seconds 120

Write-Host "Starting services with docker-compose up..." -ForegroundColor Yellow
docker-compose up -d 2>&1

Write-Host "Waiting for services to start..." -ForegroundColor Yellow
Start-Sleep -Seconds 30

Write-Host "`nChecking container status:" -ForegroundColor Green
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"

Write-Host "`nChecking notification-service logs:" -ForegroundColor Green
docker logs notification-service --tail 30

Write-Host "`nDone!" -ForegroundColor Green
