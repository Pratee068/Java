Write-Host "=== Java Microservices Test Script ===" -ForegroundColor Cyan
Write-Host ""

# Test 1: Check Docker
Write-Host "[1] Checking Docker..." -ForegroundColor Yellow
try {
    docker --version | Out-Host
    Write-Host "✓ Docker is available" -ForegroundColor Green
} catch {
    Write-Host "✗ Docker not available" -ForegroundColor Red
    exit 1
}

# Test 2: Start services
Write-Host "`n[2] Starting services..." -ForegroundColor Yellow
docker-compose down -v | Out-Host
docker-compose up -d --build | Out-Host
Write-Host "Services starting... waiting 90 seconds" -ForegroundColor Yellow
Start-Sleep -Seconds 90

# Test 3: Check container status
Write-Host "`n[3] Container Status:" -ForegroundColor Yellow
docker ps --format "table {{.Names}}`t{{.Status}}`t{{.Ports}}" | Out-Host

# Test 4: Test User Service
Write-Host "`n[4] Testing User Service..." -ForegroundColor Yellow
try {
    $users = Invoke-RestMethod -Uri "http://localhost:8081/api/users" -Method GET -TimeoutSec 10
    Write-Host "✓ User Service is responding" -ForegroundColor Green
    Write-Host "  Current users: $($users.Count)" -ForegroundColor Gray
} catch {
    Write-Host "✗ User Service failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 5: Create a user
Write-Host "`n[5] Creating test user..." -ForegroundColor Yellow
try {
    $userBody = '{"name":"John Doe","email":"john@test.com","phone":"123-456-7890"}'
    $user = Invoke-RestMethod -Uri "http://localhost:8081/api/users" -Method POST -Body $userBody -ContentType "application/json" -TimeoutSec 10
    Write-Host "✓ User created successfully!" -ForegroundColor Green
    Write-Host "  User ID: $($user.id)" -ForegroundColor Gray
    Write-Host "  Name: $($user.name)" -ForegroundColor Gray
    $userId = $user.id
} catch {
    Write-Host "✗ Failed to create user: $($_.Exception.Message)" -ForegroundColor Red
    $userId = 1
}

# Test 6: Test Order Service
Write-Host "`n[6] Testing Order Service..." -ForegroundColor Yellow
try {
    $orders = Invoke-RestMethod -Uri "http://localhost:8082/api/orders" -Method GET -TimeoutSec 10
    Write-Host "✓ Order Service is responding" -ForegroundColor Green
    Write-Host "  Current orders: $($orders.Count)" -ForegroundColor Gray
} catch {
    Write-Host "✗ Order Service failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 7: Create an order
Write-Host "`n[7] Creating test order..." -ForegroundColor Yellow
try {
    $orderBody = "{`"userId`":$userId,`"productName`":`"MacBook Pro`",`"quantity`":1,`"totalAmount`":2499.99}"
    $order = Invoke-RestMethod -Uri "http://localhost:8082/api/orders" -Method POST -Body $orderBody -ContentType "application/json" -TimeoutSec 10
    Write-Host "✓ Order created successfully!" -ForegroundColor Green
    Write-Host "  Order ID: $($order.id)" -ForegroundColor Gray
    Write-Host "  Product: $($order.productName)" -ForegroundColor Gray
    Write-Host "  Total: `$$(order.totalAmount)" -ForegroundColor Gray
} catch {
    Write-Host "✗ Failed to create order: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 8: Check MySQL data
Write-Host "`n[8] Checking MySQL data..." -ForegroundColor Yellow
Write-Host "User data:" -ForegroundColor Cyan
docker exec mysql-user mysql -uuserservice -puserpassword -e "SELECT * FROM userdb.users;" 2>&1 | Out-Host

Write-Host "Order data:" -ForegroundColor Cyan
docker exec mysql-order mysql -uorderservice -porderpassword -e "SELECT * FROM orderdb.orders;" 2>&1 | Out-Host

# Test 9: Check Notification Service logs
Write-Host "`n[9] Checking Notification Service logs..." -ForegroundColor Yellow
docker logs notification-service --tail 20 2>&1 | Out-Host

Write-Host "`n=== Test Complete ===" -ForegroundColor Cyan
Write-Host ""
Write-Host "Services are running at:" -ForegroundColor Yellow
Write-Host "  User Service:    http://localhost:8081/api/users" -ForegroundColor White
Write-Host "  Order Service:   http://localhost:8082/api/orders" -ForegroundColor White
Write-Host ""
