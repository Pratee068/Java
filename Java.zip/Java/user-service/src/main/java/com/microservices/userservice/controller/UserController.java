package com.microservices.userservice.controller;

import com.microservices.userservice.model.User;
import com.microservices.userservice.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * User Controller - REST API Endpoints
 * 
 * This controller exposes REST API endpoints for user management.
 * All endpoints are prefixed with /api/users
 * 
 * Available Endpoints:
 * - GET    /api/users          - Get all users
 * - GET    /api/users/{id}     - Get user by ID
 * - POST   /api/users          - Create new user
 * - PUT    /api/users/{id}     - Update existing user
 * - DELETE /api/users/{id}     - Delete user
 * 
 * Returns JSON responses with appropriate HTTP status codes
 */
@RestController  // Marks this as a REST controller (combines @Controller and @ResponseBody)
@RequestMapping("/api/users")  // Base path for all endpoints in this controller
public class UserController {
    
    @Autowired  // Automatically injects UserService dependency
    private UserService userService;
    
    /**
     * GET /api/users
     * Retrieve all users from the database
     * 
     * @return 200 OK with list of all users
     */
    @GetMapping  // Maps HTTP GET requests to this method
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }
    
    /**
     * GET /api/users/{id}
     * Retrieve a specific user by their ID
     * 
     * @param id The user's unique identifier from URL path
     * @return 200 OK with user data if found, 404 NOT FOUND if not found
     */
    @GetMapping("/{id}")  // {id} is a path variable
    public ResponseEntity<User> getUserById(@PathVariable Long id) {
        return userService.getUserById(id)
            .map(ResponseEntity::ok)  // If user found, return 200 OK
            .orElse(ResponseEntity.notFound().build());  // If not found, return 404
    }
    
    /**
     * POST /api/users
     * Create a new user
     * 
     * @param user User data from request body (JSON)
     * @return 201 CREATED with the created user data
     */
    @PostMapping  // Maps HTTP POST requests to this method
    public ResponseEntity<User> createUser(@RequestBody User user) {
        User createdUser = userService.createUser(user);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdUser);
    }
    
    /**
     * PUT /api/users/{id}
     * Update an existing user's information
     * 
     * @param id The user ID to update
     * @param user New user data from request body
     * @return 200 OK with updated user, 404 NOT FOUND if user doesn't exist
     */
    @PutMapping("/{id}")  // Maps HTTP PUT requests to this method
    public ResponseEntity<User> updateUser(@PathVariable Long id, @RequestBody User user) {
        try {
            User updatedUser = userService.updateUser(id, user);
            return ResponseEntity.ok(updatedUser);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    /**
     * DELETE /api/users/{id}
     * Delete a user from the database
     * 
     * @param id The user ID to delete
     * @return 204 NO CONTENT (successful deletion)
     */
    @DeleteMapping("/{id}")  // Maps HTTP DELETE requests to this method
    public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
        return ResponseEntity.noContent().build();  // 204 No Content
    }
}
