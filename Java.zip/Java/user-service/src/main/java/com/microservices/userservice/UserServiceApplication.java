package com.microservices.userservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * User Service Application - Main entry point
 * 
 * This is the main Spring Boot application class for the User Service microservice.
 * It manages user-related operations including CRUD operations for user data.
 * 
 * Port: 8081
 * Database: H2 in-memory database
 * 
 * @author Microservices Team
 * @version 1.0.0
 */
@SpringBootApplication  // Enables auto-configuration, component scanning, and configuration
public class UserServiceApplication {
    
    /**
     * Main method - Application entry point
     * Starts the Spring Boot application and initializes all components
     * 
     * @param args Command line arguments
     */
    public static void main(String[] args) {
        SpringApplication.run(UserServiceApplication.class, args);
    }
}
