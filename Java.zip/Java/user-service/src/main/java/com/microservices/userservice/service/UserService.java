package com.microservices.userservice.service;

import com.microservices.userservice.model.User;
import com.microservices.userservice.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * User Service - Business Logic Layer
 * 
 * This service class contains the business logic for user management operations.
 * It acts as an intermediary between the Controller (REST API) and Repository (Database).
 * 
 * Responsibilities:
 * - Validate business rules
 * - Coordinate operations between multiple repositories if needed
 * - Transform data between entities and DTOs
 * - Handle business logic and calculations
 */
@Service  // Marks this as a Spring service component (business logic layer)
public class UserService {
    
    @Autowired  // Automatically injects UserRepository dependency
    private UserRepository userRepository;
    
    /**
     * Retrieve all users from the database
     * 
     * @return List of all users
     */
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
    
    /**
     * Find a specific user by their ID
     * 
     * @param id The user's unique identifier
     * @return Optional containing the user if found, empty otherwise
     */
    public Optional<User> getUserById(Long id) {
        return userRepository.findById(id);
    }
    
    /**
     * Create a new user in the database
     * 
     * @param user The user object to create
     * @return The created user with generated ID
     */
    public User createUser(User user) {
        return userRepository.save(user);
    }
    
    /**
     * Update an existing user's information
     * 
     * @param id The ID of the user to update
     * @param userDetails The new user details
     * @return The updated user
     * @throws RuntimeException if user not found
     */
    public User updateUser(Long id, User userDetails) {
        // Find the existing user or throw exception if not found
        User user = userRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("User not found with id: " + id));
        
        // Update the user's fields with new values
        user.setName(userDetails.getName());
        user.setEmail(userDetails.getEmail());
        user.setPhone(userDetails.getPhone());
        
        // Save and return the updated user
        return userRepository.save(user);
    }
    
    /**
     * Delete a user from the database
     * 
     * @param id The ID of the user to delete
     */
    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }
}
