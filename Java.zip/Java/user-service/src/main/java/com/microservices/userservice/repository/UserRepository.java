package com.microservices.userservice.repository;

import com.microservices.userservice.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * User Repository - Data Access Layer
 * 
 * This interface provides database operations for User entities.
 * By extending JpaRepository, it automatically gets CRUD operations:
 * - save(): Create or update a user
 * - findById(): Find user by ID
 * - findAll(): Get all users
 * - deleteById(): Delete user by ID
 * - count(): Count total users
 * - and many more...
 * 
 * Spring Data JPA automatically implements this interface at runtime.
 * No need to write implementation code!
 */
@Repository  // Marks this as a Spring Data repository component
public interface UserRepository extends JpaRepository<User, Long> {
    // JpaRepository provides all basic CRUD operations
    // Custom query methods can be added here if needed
    // Example: List<User> findByEmail(String email);
}
