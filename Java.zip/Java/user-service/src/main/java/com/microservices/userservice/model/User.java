package com.microservices.userservice.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * User Entity - Represents a user in the system
 * 
 * This entity is mapped to the "users" table in the H2 database.
 * Contains basic user information including name, email, and phone number.
 * 
 * Lombok annotations are used to reduce boilerplate code:
 * - @Data: Generates getters, setters, toString, equals, and hashCode
 * - @NoArgsConstructor: Generates no-args constructor
 * - @AllArgsConstructor: Generates constructor with all fields
 */
@Entity  // Marks this class as a JPA entity
@Table(name = "users")  // Maps to "users" table in database
@Data  // Lombok: Generates getters, setters, toString, equals, and hashCode
@NoArgsConstructor  // Lombok: Generates constructor with no parameters
@AllArgsConstructor  // Lombok: Generates constructor with all parameters
public class User {
    
    @Id  // Marks this field as the primary key
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // Auto-generates ID using database identity column
    private Long id;  // Unique identifier for the user
    
    private String name;  // User's full name
    private String email;  // User's email address
    private String phone;  // User's phone number
}
