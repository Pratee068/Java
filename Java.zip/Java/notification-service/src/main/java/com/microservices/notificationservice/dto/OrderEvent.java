package com.microservices.notificationservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * OrderEvent Data Transfer Object (DTO)
 * 
 * This class represents an order event received from Kafka.
 * It mirrors the OrderEvent from Order Service but exists in the
 * Notification Service codebase for decoupling.
 * 
 * Purpose:
 * - Deserializes JSON messages from Kafka
 * - Contains order information needed for notifications
 * - Decouples Notification Service from Order Service's internal structure
 * 
 * Events Received:
 * - Order created events
 * - Order status update events
 * - Any order-related changes
 */
@Data  // Lombok: Generates getters, setters, toString, equals, and hashCode
@NoArgsConstructor  // Lombok: Required for JSON deserialization from Kafka
@AllArgsConstructor  // Lombok: Generates constructor with all fields
public class OrderEvent {
    private Long orderId;  // ID of the order
    private Long userId;  // ID of the user who placed the order
    private String productName;  // Product name
    private Integer quantity;  // Quantity ordered
    private Double totalAmount;  // Total order amount
    private String status;  // Current order status (PENDING, SHIPPED, etc.)
    private String message;  // Human-readable message about the event
}
