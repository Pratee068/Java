package com.microservices.notificationservice.config;

import com.microservices.notificationservice.dto.OrderEvent;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.support.serializer.JsonDeserializer;

import java.util.HashMap;
import java.util.Map;

/**
 * Kafka Consumer Configuration
 * 
 * This configuration class sets up Kafka consumer beans for receiving messages.
 * It configures:
 * - Kafka broker connection
 * - Deserialization (converts bytes to Java objects)
 * - Consumer settings for reliability and performance
 * - Message listener containers
 * 
 * Key Components:
 * - ConsumerFactory: Creates Kafka consumer instances
 * - KafkaListenerContainerFactory: Manages listener containers
 * - Deserializers: Convert JSON messages to Java objects
 * 
 * Important Configuration:
 * - Consumer Group: Multiple consumers in same group share message load
 * - Deserialization: Converts JSON from Kafka to OrderEvent objects
 * - Type Mappings: Maps producer's class names to consumer's classes
 */
@Configuration  // Marks this as a Spring configuration class
public class KafkaConsumerConfig {
    
    /**
     * Kafka broker address from application.properties
     * Format: host:port (e.g., localhost:9092)
     */
    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;
    
    /**
     * Consumer group ID from application.properties
     * Consumers in the same group share the message load
     */
    @Value("${spring.kafka.consumer.group-id}")
    private String groupId;
    
    /**
     * Consumer Factory Bean
     * 
     * Creates and configures the Kafka consumer factory.
     * This factory is used to create consumer instances.
     * 
     * Configuration:
     * - BOOTSTRAP_SERVERS: Kafka broker addresses
     * - GROUP_ID: Consumer group for load balancing
     * - KEY_DESERIALIZER: Deserializes message keys from bytes to String
     * - VALUE_DESERIALIZER: Deserializes message values from JSON to OrderEvent
     * - TRUSTED_PACKAGES: Allow deserialization from all packages (*)
     * - VALUE_DEFAULT_TYPE: Default type for deserialized messages
     * - USE_TYPE_INFO_HEADERS: Don't use type headers from producer
     * - TYPE_MAPPINGS: Map producer class names to consumer class names
     * 
     * Type Mappings Explanation:
     * Order Service sends: com.microservices.orderservice.dto.OrderEvent
     * Notification Service expects: com.microservices.notificationservice.dto.OrderEvent
     * Mapping tells deserializer to convert between these class names
     * 
     * @return ConsumerFactory configured for OrderEvent messages
     */
    @Bean
    public ConsumerFactory<String, OrderEvent> consumerFactory() {
        Map<String, Object> config = new HashMap<>();
        
        // Kafka broker address
        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        
        // Consumer group ID (for load balancing)
        config.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        
        // Deserialize message keys as strings
        config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        
        // Deserialize message values as JSON
        config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
        
        // Trust all packages for deserialization (use cautiously in production)
        config.put(JsonDeserializer.TRUSTED_PACKAGES, "*");
        
        // Default type for deserializing messages
        config.put(JsonDeserializer.VALUE_DEFAULT_TYPE, OrderEvent.class.getName());
        
        // Map producer's class name to consumer's class name
        // This allows services to have different package structures
        config.put(JsonDeserializer.TYPE_MAPPINGS, 
            "orderEvent:com.microservices.notificationservice.dto.OrderEvent," +
            "com.microservices.orderservice.dto.OrderEvent:com.microservices.notificationservice.dto.OrderEvent");
        
        return new DefaultKafkaConsumerFactory<>(config);
    }
    
    /**
     * Kafka Listener Container Factory Bean
     * 
     * Creates the factory that manages @KafkaListener containers.
     * The container handles:
     * - Message polling from Kafka
     * - Deserialization of messages
     * - Invoking listener methods
     * - Error handling
     * - Concurrent processing
     * 
     * @return ConcurrentKafkaListenerContainerFactory for OrderEvent messages
     */
    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, OrderEvent> kafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, OrderEvent> factory = 
            new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory());
        return factory;
    }
}
