package com.microservices.notificationservice.service;

import com.microservices.notificationservice.dto.OrderEvent;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

/**
 * Kafka Consumer Service - Message Processing
 * 
 * This service consumes order events from Kafka and processes notifications.
 * It demonstrates asynchronous, event-driven communication in microservices.
 * 
 * Flow:
 * 1. Order Service publishes event to Kafka topic "order-events"
 * 2. Kafka stores the message
 * 3. This consumer receives the message asynchronously
 * 4. Event is deserialized from JSON to OrderEvent object
 * 5. Notification is processed and sent
 * 
 * Benefits:
 * - Decoupling: Order Service doesn't need to know about Notification Service
 * - Scalability: Multiple consumers can process messages in parallel
 * - Reliability: Kafka ensures message delivery even if consumer is down
 * - Asynchronous: Order Service doesn't wait for notification to complete
 */
@Service  // Marks this as a Spring service component
public class KafkaConsumerService {
    
    /**
     * Kafka Listener Method - Consumes Order Events
     * 
     * This method is automatically called by Spring Kafka whenever a new message
     * arrives on the "order-events" topic.
     * 
     * Annotations:
     * - @KafkaListener: Marks this method as a Kafka message consumer
     *   - topics: The Kafka topic(s) to listen to
     *   - groupId: Consumer group ID (allows multiple consumers to share load)
     * 
     * How it works:
     * 1. Kafka receives message from Order Service
     * 2. Spring Kafka deserializes JSON to OrderEvent object
     * 3. This method is invoked with the OrderEvent parameter
     * 4. Method processes the event and sends notifications
     * 
     * @param orderEvent The order event received from Kafka
     */
    @KafkaListener(
        topics = "${spring.kafka.topic.order-events}",  // Topic name from config
        groupId = "${spring.kafka.consumer.group-id}"   // Consumer group from config
    )
    public void consumeOrderEvent(OrderEvent orderEvent) {
        // Display formatted notification in console
        System.out.println("=================================================");
        System.out.println("📧 NOTIFICATION SERVICE - New Order Event Received");
        System.out.println("=================================================");
        System.out.println("Order ID: " + orderEvent.getOrderId());
        System.out.println("User ID: " + orderEvent.getUserId());
        System.out.println("Product: " + orderEvent.getProductName());
        System.out.println("Quantity: " + orderEvent.getQuantity());
        System.out.println("Total Amount: $" + orderEvent.getTotalAmount());
        System.out.println("Status: " + orderEvent.getStatus());
        System.out.println("Message: " + orderEvent.getMessage());
        System.out.println("=================================================");
        
        // Process the notification
        // In a real application, this would:
        // - Send email notifications
        // - Send SMS notifications
        // - Send push notifications
        // - Log to notification database
        sendNotification(orderEvent);
    }
    
    /**
     * Send Notification
     * 
     * This method simulates sending a notification to the user.
     * In a production system, this would integrate with:
     * - Email services (SendGrid, AWS SES, etc.)
     * - SMS services (Twilio, AWS SNS, etc.)
     * - Push notification services (Firebase, OneSignal, etc.)
     * - Internal notification database
     * 
     * @param orderEvent The order event to create notification from
     */
    private void sendNotification(OrderEvent orderEvent) {
        // Create a user-friendly notification message
        String notificationMessage = String.format(
            "Dear User %d, your order #%d for %s has been %s. Total: $%.2f",
            orderEvent.getUserId(),
            orderEvent.getOrderId(),
            orderEvent.getProductName(),
            orderEvent.getStatus(),
            orderEvent.getTotalAmount()
        );
        
        // In production, replace this with actual notification service calls
        System.out.println("✅ Notification sent: " + notificationMessage);
        
        // Example integrations (commented out):
        // emailService.sendEmail(user.getEmail(), "Order Update", notificationMessage);
        // smsService.sendSMS(user.getPhone(), notificationMessage);
        // pushNotificationService.send(user.getId(), notificationMessage);
    }
}
