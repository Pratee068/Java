package com.microservices.notificationservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Notification Service Application - Main entry point
 * 
 * This is the main Spring Boot application class for the Notification Service.
 * This microservice is a Kafka consumer that listens to order events and
 * processes notifications.
 * 
 * Purpose:
 * - Consume order events from Kafka
 * - Process notifications (email, SMS, push notifications, etc.)
 * - Decouple notification logic from Order Service
 * 
 * Communication Pattern:
 * - Asynchronous: Consumes messages from Kafka "order-events" topic
 * - Event-driven: Reacts to events published by Order Service
 * 
 * Port: 8083
 * 
 * @author Microservices Team
 * @version 1.0.0
 */
@SpringBootApplication  // Enables auto-configuration, component scanning, and configuration
public class NotificationServiceApplication {
    
    /**
     * Main method - Application entry point
     * Starts the Spring Boot application and initializes Kafka consumers
     * 
     * @param args Command line arguments
     */
    public static void main(String[] args) {
        SpringApplication.run(NotificationServiceApplication.class, args);
    }
}
